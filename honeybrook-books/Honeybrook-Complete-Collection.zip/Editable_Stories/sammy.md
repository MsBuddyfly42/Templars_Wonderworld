# SAMMY PATCHWELL AND THE COAT THAT CAME HOME
## Honeybrook Beginnings - Book Three

### Chapter 1: The Bear outside Supper

Sammy arrived while the supper bowls were being filled.

He could smell soup from the road. He could hear spoons, chairs, and bears talking to one another as though they already knew where they belonged.

He stopped outside the shelter.

His coat was much too big. Its patches were different colors, sewn with crooked stitches. One sleeve covered most of his paw.

He had no bag. No parents or relatives stood behind him.

Amelia saw him through the open door.

"Hello," she said. "Would you like a bowl?"

Sammy looked at the bowl, then at her.

"What does it cost?"

"Nothing."

He waited for the next part.

There was usually a next part.

Amelia did not fill the silence with questions. She moved a chair where he could see the door.

"You can sit here."

Sammy stepped inside slowly.

He thought he was about eleven. He knew his first name.

For the moment, those were the only facts he wanted to bring into the room.

The soup smelled warm.

### Chapter 2: What the Coat Remembered

Before Honeybrook, Sammy had learned a great deal about leaving.

He knew how to save a crust inside his sleeve. He knew how to curl up small enough to fit beside a sheltered wall. He knew that a voice calling come here did not always mean welcome.

There were parts of his past he did not want to say aloud.

This story does not make him tell them before he can have supper.

But the last stretch of road could be remembered in little pieces.

A windy morning. A wrong turning. The sound of rain against a roof where he could rest only until the owner returned.

His coat caught on a branch. Sammy tried to mend it with a scrap and some thread he had kept. The new patch sagged over the old one.

It was badly sewn.

It still covered the hole.

Later, a traveler pointed him toward a valley where bears had built a bridge and a shelter.

Sammy did not trust the promise of a welcoming place.

He followed the road anyway, because he had nowhere else to go.

By sunset, he smelled soup.

That was how the last part of his journey became the first part of Honeybrook.

### Chapter 3: Bread for Tomorrow

Sammy ate quickly.

When nobody was looking directly at him, he put a piece of bread inside his coat.

Amelia noticed. She did not pull it out or ask him to explain in front of the others.

After supper, she showed him a sleeping place.

"For how long?" he asked.

"You can rest tonight. We can talk again tomorrow."

He lay down in his shoes. His paws held the blanket close.

The room made small noises: a settling board, the last bowl being washed, wind at the window.

Sammy woke several times, expecting somebody to tell him to move.

Nobody did.

In the morning there was breakfast.

The hidden bread was still in his pocket, but he did not need it yet.

Amelia offered him a place at the table. Tom asked whether the bed had squeaked. Sammy nodded reluctantly.

Tom fixed the loose corner that afternoon.

Sammy watched from the door.

"What do I owe?"

"Nothing. It was a bed that needed fixing."

That answer was nearly as difficult to understand as a printed word.

The following night, Sammy kept his shoes on again. He could hear the repaired bed settling beneath him, steady and less noisy.

He wondered whether being comfortable would make leaving harder.

In the morning, Amelia asked whether he wanted to eat at the table or on the covered bench. He chose the bench.

She brought his bowl without asking him to explain why.

A choice so small should have been easy. Sammy was surprised by how much it mattered.

Nobody treated eating outside as a rejection of the shelter. He could want some quiet and still be welcome inside later.

That afternoon he came back for water and stayed through the meal.

He still kept a little bread.

Trust did not arrive as quickly as a bowl of soup. The town had to be the same kind of place tomorrow too.

Sammy took a long time learning to believe it.

### Chapter 4: A Hammer Is Not a Test

Tom invited Sammy to watch a small repair.

Sammy was nervous, but he thought perhaps this was the part where he could become useful enough to stay.

He picked up a nail.

It dropped.

He picked up another.

That dropped too.

When he tried the hammer, he struck his thumb. It hurt, and the embarrassment hurt almost as much.

"I'm no good at it," he said.

Tom set the tools down.

"Let's look after that thumb."

Sammy waited for disappointment. Tom brought a cool cloth and checked the little injury, then offered to finish the repair himself.

The next day Sammy tried gardening. He confused a new sprout with a weed.

At the cooking table, he worried about using too much of an ingredient. He had wasted things before and been frightened by what came afterward.

A bear pointed out a word on a sack. Sammy could not read it.

He moved farther from the busy table.

Amelia found him outside.

"If I can't do anything," he asked, "where do I go?"

She sat beside him.

"You don't have to go."

"But the hammer."

"Was a hammer. It wasn't an entrance test."

Sammy looked at his bandaged thumb.

Nobody took away his bed.

For several days Sammy avoided the work table anyway. He had heard Amelia's answer, but he was not certain it would remain true after one more mistake.

Tom greeted him when he passed. The cook offered supper. Amelia asked whether he had found a comfortable place to rest.

They did not bring the dropped nails into every conversation.

One afternoon Tom offered a place nearby while he worked. Sammy asked whether he had to help.

"No."

Sammy sat and watched the light change on the wall.

After a while he asked what Tom was making. Tom answered. Sammy asked another question.

It was a conversation, not a test.

He left before the repair was finished. Tom said goodbye as if that were an ordinary thing a bear could do.

The next morning, Sammy passed the table again.

He did not need to hide from it quite as much.

### Chapter 5: Only Sammy

A list was being made of the bears living in the settlement.

Sammy watched Amelia write their names. Some were long. Some had familiar family names after them.

When his turn came, he went quiet.

"Sammy," he said.

Amelia waited.

"Only Sammy."

She wrote it.

The space after his name seemed enormous to him.

"Do I need another?"

"You don't need it to stay."

That helped, but he kept thinking about the list.

A neighbor offered to mend his coat. Sammy drew it close, afraid she meant to take it away and give him something he could not keep.

Amelia said he could choose.

He allowed one seam to be repaired while he watched. The patches stayed where they were.

The neighbor did not call the coat ugly. She asked which pieces mattered to him.

Sammy touched a faded blue patch and an uneven yellow one.

They had covered holes for a long time.

Later, he asked Amelia whether a bear could choose a name.

"Yes," she said. "We can think about it together."

He tried several sounds quietly before supper.

None fitted as well as the coat.

Amelia asked which name he liked when nobody else was listening.

Sammy was pleased she asked that way. An audience might have made him choose whatever ended the conversation fastest.

He tried saying a possible surname beside his own name. It sounded like a costume borrowed from a larger bear.

Another sounded too much like a place he did not want to remember.

He put both aside.

The coat lay on his knees. Its patches were not beautiful, but he knew them. They belonged to the journey he had made, and he could choose what they would mean next.

He did not have to throw away everything from before Honeybrook to become a Honeybrook bear.

He wanted a name that could hold both parts of his life without explaining all of them.

He touched the blue patch once more.

The sound began forming in his mind.

### Chapter 6: Patchwell

"Patchwell," Sammy said.

He was sitting beside Amelia with the coat across his knees.

She repeated it slowly.

He nodded.

It came from the pieces that had held together, however crookedly, through miles of road.

They tried it after Samuel, a fuller form of Sammy he liked. He still wanted people to call him Sammy most of the time.

Amelia wrote SAMUEL PATCHWELL on the list.

He watched the letters without being able to read them all.

"Is that really me?"

"That's your name on paper. You were already you."

Sammy traced the shape of the first letter in the air.

The name did not turn him into a different kind of bear.

The next morning he still dropped something. He still struggled with the word on the flour sack. He still worried when a bowl was pushed toward him too quickly.

But when a traveler asked who lived in the shelter, he could answer.

"I do."

He pointed toward the list.

Then he went to get another chair.

For the first time, that ordinary movement felt as if it belonged to his own house.

### Chapter 7: The New Bear at the Door

A newcomer arrived one afternoon and stood outside the shelter.

Other bears offered maps, suggestions, and questions. All of them meant well.

The newcomer seemed to grow smaller under the attention.

Sammy recognized the look.

He took his bowl outside and sat on the bench, leaving plenty of room.

"You can sit here if you want," he said. "You don't have to talk."

The bear sat.

For a while they ate without speaking.

Sammy did not ask where the bear's family was. He did not ask what useful work the bear could do. He did not describe every lovely thing in Honeybrook and wait for a grateful smile.

He let the soup be soup and the bench be a bench.

At last the newcomer asked whether there was somewhere to sleep.

Sammy showed the way.

Later, Amelia asked what had helped.

"Not being asked so much," Sammy said.

She thought about that for a long time.

Honeybrook's next welcoming place would need space for silence too.

The newcomer did not become talkative the next morning.

Sammy was glad nobody expected that.

He saw the bear reading a map quietly, then choosing to put it away. At supper, the bear asked one question about the road.

Sammy answered what he knew and took the rest to Amelia.

He did not pretend to know everything simply because he had lived there longer.

The next day the newcomer chose to leave, grateful for a rest but not ready to settle.

Sammy felt disappointed for a moment. He had hoped they might become friends.

Amelia reminded him that a good welcome could end with a bear continuing a journey.

The bed remained for the next person.

Sammy understood that making room was not the same as keeping someone.

He sat on the bench again that afternoon, with no story to demand and no promise to collect.

Sammy had not discovered a secret talent.

He had noticed another bear standing where he had once stood.

### Chapter 8: A House That Starts with Hello

The town made plans for Welcome House.

It would have beds, food, information, and a place to rest before deciding what came next.

At a planning conversation, someone suggested checking new arrivals' skills immediately so work could be found for them.

Sammy looked at Amelia.

"Could that wait?"

The other bear explained that it was meant to help.

"I know," Sammy said. "But they could hear it as what must I do to stay?"

Tom made the entrance room more comfortable. Amelia kept the first questions simple. The bench remained beside the door.

Sammy helped when he could. He misplaced a broom. He mixed up two names. On a busy morning he needed someone to repeat an instruction.

Nobody turned those mistakes into a joke about whether he should have been welcomed.

The sign beside the door said:

YOU DON'T HAVE TO BRING ANYTHING BUT YOURSELF.

Sammy looked at it often.

He could not read it quickly yet.

He knew what it meant.

The next traveler found him on the bench.

Sammy moved his bowl to make room.

### Chapter 9: The Beginning of the Book

Time passed. Families came. The Hearthwells filled a new home with voices, ideas, songs, and an extraordinary number of small belongings.

Several months after their arrival, Professor Theodore Honeywell came to the settlement.

He carried books and spoke very properly.

Sammy kept away at first.

A school seemed like another place where everyone would discover what he could not do.

The Professor eventually offered a private lesson, with no crowd watching. They used familiar objects and short words.

Sammy forgot one word he had known yesterday.

The Professor tried another way.

Sammy looked suspicious.

"Are you going to get tired of me?"

The Professor closed the book for a moment.

"We can take breaks. We don't have to stop believing you can learn."

Sammy's progress was slow. Some days were hard. There was no sudden moment when he became the finest reader in town.

There were mornings when he knew a little more than before.

And there was a place to begin again the next day.

### Chapter 10: The Coat in the Case

Many years later, Welcome House displayed Sammy's old coat.

The crooked patches could still be seen beneath later repairs.

The plaque read:

SAMUEL PATCHWELL - FIRST BEAR WELCOMED HOME.

Sammy read the words slowly.

A cub looking into the case asked whether he had been allowed to stay because he became good at helping newcomers.

Amelia shook her head.

"He was allowed to stay before we knew any of that."

Sammy looked at her.

The truth had been there from the first bowl, the repaired bed, and the untouched bread in his pocket.

He had needed time to understand it.

He was still an ordinary bear. He could have difficult days. Some things remained hard to learn. His friends knew him and made room.

Outside, someone sat on the bench with a small bag.

Sammy took a bowl from the kitchen.

He went to sit nearby.

The coat had finished its traveling.

The welcome had not.

### Story Note

Sammy's age, solitary arrival, oversized patched coat, ordinary abilities, chosen name, and Welcome House legacy follow the original Honeybrook storyline. His last days on the road and these conversations are fictional expansions. His deeper past is left private. He never has to reveal a secret gift or prove his usefulness to belong.
