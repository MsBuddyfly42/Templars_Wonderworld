# TOM BRIDGEWELL AND THE ROAD THAT BECAME HOME
## Honeybrook Beginnings - Book Two

### Chapter 1: The Road Stops Here

Tom Bridgewell arrived at the creek just as a wheel on his cart began to squeak.

"One problem at a time," he told it.

Then he saw the bridge.

Its middle had dropped toward the water. The road continued on the other side, perfectly visible and impossible to reach.

The cart squeaked again.

"Yes," Tom said. "Now we have two."

He set down his tool bag and called across the creek.

A young bear crawled out from under the broken boards.

She had been sleeping there.

Tom asked whether there was another crossing. She did not know. She had only arrived the day before.

Her name was Amelia Honeybrook.

There was no town around her. No Works Yard. No Builder Bear waiting for a job.

There was only a stranded traveler with tools, a young bear with nowhere to go, and a bridge that could no longer do its work.

Tom looked at the sound timber on his side.

The road had stopped.

Perhaps his journey had not.

### Chapter 2: A Builder on the Move

Before the creek, Tom had traveled from place to place.

He was a carpenter and stoneworker. He understood joints, walls, roofs, and the patient business of making things stand.

In one village he had repaired a market stall. In another he had helped with a damaged garden wall. His tools moved from cart to worksite and back again.

He liked leaving useful things behind.

But when a job ended, he packed.

There was always another road.

He knew innkeepers who remembered his name and towns where he remembered every crooked step. None of them had quite become home.

On this journey, rain had slowed the cart. A wheel had caught in mud. Tom had stopped to free it, check the load, and tighten a loose fitting before continuing.

By the time he reached the valley, he was hungry and tired.

He had expected another crossing on the way to another temporary job.

Instead he found Amelia beneath a broken bridge.

She did not ask him to make the valley grand.

She asked whether bears could get across.

That was a question Tom knew how to begin answering.

He thought of a porch he had repaired in another settlement. The owner wanted it finished quickly for a gathering. Tom found weak wood hidden beneath the surface and explained that replacing it would take longer.

The owner was disappointed.

Tom was disappointed too. He liked pleasing people. But he did not like leaving them a porch that only looked safe.

They changed the gathering place and finished the repair properly. Later, a visitor thanked him without knowing how the schedule had changed.

Another job had been a wall built for a garden. Tom made the entrance wide enough for the owner's cart, then wider still when the owner remembered a neighbor who would help with deliveries.

Those jobs had taught him to ask who would use a thing, not only how impressive it would look.

On the road, he carried those lessons with his tools.

Now he saw Amelia and the waiting travelers, and the question who will use this had an answer on both banks.

A frightened young bear needed connection. So did a builder who had grown used to leaving after every job.

Tom checked the creek again before making a plan.

### Chapter 3: Work across the Water

They started from opposite banks.

Tom explained what to inspect from safe ground. Amelia gathered pieces worth saving and kept them separate from the rotten ones.

Other travelers arrived and waited. Some offered help. Some had food. One knew knots Tom was glad to see.

Nobody stepped onto the broken crossing.

Tom made that clear before the work began.

Amelia asked many questions. She confused a beam with a plank, then corrected herself. Tom liked a question better than a guess where building was concerned.

When supplies could safely be passed across, the group worked together. The creek's noise sometimes swallowed a sentence, and they had to call it again.

At lunchtime the cook shouted, "Soup!"

That word reached every bank perfectly.

Tom noticed how Amelia looked at the other bears. She seemed surprised whenever someone made room for her by the fire.

He had been traveling with tools for years.

She had been traveling with hope and very little else.

They were stopped by the same creek.

Their journeys had been different.

On the second clear morning, a helper wanted to drag a heavy piece into place before Tom had finished checking the approach.

"It will save time," the helper said.

Tom asked everyone to stop.

Amelia worried that stopping would upset the volunteers. She had seen work disappear when people felt criticized.

Tom explained the concern plainly. They moved the supplies to the safe waiting area and changed the order of tasks.

The helper nodded once he understood.

Nobody needed to be called foolish for making a suggestion that did not work.

Amelia watched how Tom held the line without making the bear smaller.

Later, she asked whether saying no was difficult.

"Sometimes," he answered.

"How do you do it?"

"I try to explain what the no is protecting."

They heard the cook calling from the higher ground. Tom checked that the tools were secured before going for lunch.

At the fire, the helper passed him bread. The disagreement had not become a reason for anyone to leave the circle.

Tom had been welcomed as a builder. He was learning what the welcome could mean beyond the work.

### Chapter 4: The Roof Question

The repaired bridge opened after the work had been checked.

Bears crossed. Baskets crossed. A small cub's pinecone crossed as if it had somewhere important to be.

Tom expected to collect his tools and continue.

Then Amelia said she wanted to stay.

She pointed to a patch of higher ground where a shelter could stand.

"Could a roof go there?"

Tom looked at the ground, the wind, and the road.

"It would need planning."

"I can learn."

He smiled.

A roof needed more than a builder, and a settlement needed more than a roof. They would have to think about water, warmth, paths, supplies, and neighbors.

Amelia listened without pretending those were small matters.

Tom could already picture the first shelter. He could also picture leaving after it was finished.

He had always left after the job was finished.

But the valley's next question was beginning before its first answer had dried.

He put his tool bag beside Amelia's little bundle.

"Let's see what we can make," he said.

### Chapter 5: Strong and Useful

The shelter taught them new lessons.

A roof could look sound and still leak. A doorway could be sturdy and still difficult to use when someone carried a wide basket.

Tom changed the doorway before he fitted the last frame.

"That takes more time," a helper said.

"It saves trouble later."

They put a covered bench beside the path. Amelia wanted travelers to have a dry place even if they were not ready to come inside.

Tom measured it for more than one size of bear.

There were large paws, small paws, and tired paws to think about.

He began to understand Amelia's promise as a building question too.

If a place welcomed bears, it needed room they could actually use.

At supper, the cook complained about the third roof drip. Tom repaired it the next morning.

Amelia brought bread that was rather hard.

Tom ate it carefully and declined to suggest using it for the wall.

She laughed when she realized what he was thinking.

The shelter was becoming more than a job.

One night, Tom woke when the roof made an unfamiliar sound in the wind. He checked from inside, then waited for daylight to inspect the outside safely.

Amelia found him studying the drawing after breakfast.

"Is something wrong?"

"Something to look at. That's different from knowing something is wrong."

They asked another experienced builder to review the plan with him. A second pair of eyes found a small improvement near the eaves.

Tom made the change.

Amelia looked surprised that he had asked for help.

"You're the builder."

"Yes. I'm also one bear."

He showed her the note on the drawing. Good work did not become less his work because another bear improved it.

That afternoon, a cub watched them fit a low shelf. Tom asked the cub which belongings needed a place. The answer included a pinecone, two stones, and a feather of considerable importance.

The shelf was arranged accordingly.

It was not the most impressive thing Tom had made. He enjoyed seeing it used all the same.

A home had room for things that did not earn money, solve problems, or hold up a roof.

Sometimes they simply mattered to the bear who kept them.

### Chapter 6: The Bag by the Door

One morning Tom repaired the squeaking cart wheel.

Then he packed the tools he was not using that day.

Amelia found him beside the bag.

"Are you leaving?"

He had not decided. There were still places farther down the road and bears who might need a builder.

"I usually move on," he said.

Amelia nodded, though her ears lowered a little.

"You can."

She did not ask him to stay because the settlement could not manage without him. She did not make his tools the price of his place.

"You'd still have a bed if you wanted to come back," she said.

Tom looked toward the bridge.

He had often left useful things behind.

He had less often been invited to return without another job waiting.

That afternoon he walked along the road alone, far enough to see the valley from the rise.

Smoke lifted from the shelter chimney. Bears moved between the bridge and the new cottage.

He knew where supper would be.

He turned back.

On the way down, he met one of the travelers who had crossed the repaired bridge. The traveler was passing through again and stopped to say hello.

"Still here?"

Tom nodded.

"For another job?"

He looked toward the cottages.

"Perhaps for another kind of beginning."

The traveler did not need the answer explained further. They stood together for a moment, then went toward the shelter.

At the door, Amelia was helping clear space for supper. She did not ask Tom to announce his decision in front of everyone.

She offered him a bowl.

He sat where his tool bag had usually stood and listened to the conversation. The cook wanted a better place for dry supplies. A neighbor had an idea for a garden. Someone asked whether a porch bench could be made comfortable for larger bears too.

There would always be more work.

Tom realized the work was not the reason he wanted to return. It was the company around it, and the certainty that a bowl would still be offered on a day he put his tools away.

He stayed after supper to wash dishes.

Then he left the cart unpacked for the morning.

### Chapter 7: Tom Stays

Tom placed his bag beside the shelter wall.

"I'll need a proper place for these," he said.

Amelia smiled before she answered.

"We'll make one."

He stayed.

At first, Tom tried to keep his few belongings packed neatly beside the bed. He was so used to leaving that putting things on a shelf seemed to make a promise he might not understand.

Amelia did not rush him.

One day he set a spare tool on the new workshop shelf. The following morning he hung his coat on a peg instead of folding it for the cart.

Small belongings began taking their ordinary places.

A neighbor asked whether Tom would like to join a quiet evening by the creek. There was no broken object at the gathering and no task waiting for him.

He almost asked what help was needed.

Then he went simply to sit.

The bears talked about weather, a lost spoon, and the cook's continued campaign for Turnip Lane. Tom laughed and told a story about a cart wheel that had complained through three villages.

When he returned to his bed, the tool was still on the shelf and the coat still on the peg.

He could have left the next day if he wished. Knowing he was free to choose made staying feel more like home, not less.

In the morning he fixed the squeaking cart again, then used it to carry supplies along Honeybrook's own path.

The cart was still a traveling cart.

It had new places to go.

The settlement became Honeybrook. Tom helped with its early cottages and paths, and later with the buildings that a growing town needed.

He remained practical. He could be cheerful without calling unsafe work safe. He could say wait even when everybody wanted done.

When Sammy arrived alone, Tom offered him a place to watch a small repair. Sammy dropped nails and hurt his thumb.

Tom put the tools aside.

"We can stop."

Sammy was surprised.

Tom had learned something from Amelia's open door: a bear could belong without becoming a builder.

The next afternoon, Sammy sat nearby while Tom worked.

He did not pick up the hammer.

Nobody took away his seat.

### Chapter 8: Bears He Had Never Met

Years later, Tom worked with Buddy Hearthwell at the Works Yard.

The town had grown. Children crossed the paths he had helped lay before their arrival. Visitors rested on the old covered bench.

Some did not know his name.

That did not bother him.

Lance once asked why Tom checked a repair so carefully when only a few neighbors used that route.

"We don't know everyone who will need it tomorrow," Tom said.

He showed Lance the clear entrance, steady rail, and finished surface. They belonged to familiar bears and unknown ones alike.

"Build it strong enough for bears you'll never meet."

Lance wrote the sentence down.

After the work, Tom closed his bag and went home.

He still loved a road. He still enjoyed a good journey.

But now he knew the lovely thing a road could do at the end of a day.

It could bring him back.

### Story Note

Tom's traveling-builder arrival, stranding across the creek, and partnership with Amelia are established Honeybrook facts. The earlier repair jobs and detailed scenes in this book are fictional expansions. They show how a temporary stop becomes a lasting home.
